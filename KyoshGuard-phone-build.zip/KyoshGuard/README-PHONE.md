# Build KyoshGuard using only your Android phone

This project includes a GitHub Actions workflow that builds the JAR in GitHub's cloud (you do not need Java or Gradle installed on your phone).

1. Create/sign in to GitHub in your phone browser or app.
2. Create a new repository. You may set it Public or Private.
3. Upload the contents of this ZIP into the repository, keeping the `.github/workflows/build.yml` file and folders intact. GitHub's web upload may not show hidden folders; if it skips `.github`, the workflow will not run.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab and select **Build KyoshGuard**. If it hasn't triggered automatically, tap **Run workflow**.
6. Wait for the build job to finish. Open the completed run, scroll to **Artifacts**, and download `KyoshGuard-jar`.
7. Extract the artifact ZIP; inside is the KyoshGuard JAR. Upload that JAR to your server host's `plugins` folder and restart the server.

Build workflow is provided, but the plugin has not been runtime-tested on a live Paper 26.3 server. Start with a backup and alert-only settings.
