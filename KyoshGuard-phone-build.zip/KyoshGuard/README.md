# KyoshGuard — KYOSH.DEV


Early defensive plugin foundation for Paper Minecraft 26.3. **Not a compiled JAR**: this workspace does not have Java 25 or Gradle installed, so compilation/runtime validation could not be performed here.

## Features currently implemented
- Configurable join-rate flagging (alert-only)
- Configurable command-rate monitoring, optionally cancelling excess commands
- Console and staff alerts; recent alert buffer
- `/kyoshguard help|status|alerts|check <player>|tp <player>|back|reload`
- Staff return-location handling for manual investigation teleports
- Config file with toggles and thresholds

## Not implemented / not validated
- Advanced packet-level anti-bot/anti-flood logic
- Movement/combat cheat detections
- GUI dashboard
- Webhook integrations
- Confidence scoring / punishment pipeline
- Automated teleport-on-alert is currently only a basic optional demonstration and is **not recommended for live use**. It selects the first online non-owner player; alerts do not identify a verified suspect.

## Compatibility
Paper 26.3 API dependency, Java 25 toolchain. See Paper's official project setup docs for the 26.3 API dependency and Java toolchain. Older server versions are not targeted.

## Build
Install JDK 25 and Gradle 8.14+ (or a compatible Gradle version), then run from this directory:

```sh
gradle build
```
The JAR will be in `build/libs/`.

## Install
1. Build the plugin.
2. Copy `build/libs/KyoshGuard-0.1.0.jar` into your Paper server's `plugins/` folder.
3. Start server once to create `plugins/KyoshGuard/config.yml`.
4. Stop server and adjust config if needed; restart.
5. Give staff permissions as needed (defaults are OP).

## Permissions
- `kyoshguard.admin` — reload
- `kyoshguard.view` — status/check/alerts
- `kyoshguard.alerts` — staff alerts
- `kyoshguard.investigate` — tp/back

## Caution
Join/command-rate alerts can be false positives due to reconnects, plugins, or normal command use. Start in alert-only mode and review logs before enabling command cancellation. Back up your server first.
