package dev.kyosh.guard;


import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class KyoshGuard extends JavaPlugin implements Listener {
    private final Map<UUID, Deque<Long>> joinTimes = new HashMap<>();
    private final Map<UUID, Deque<Long>> commandTimes = new HashMap<>();
    private final Map<UUID, Location> savedLocations = new HashMap<>();
    private final Deque<String> recentAlerts = new ArrayDeque<>();
    private long lastOwnerTp = 0L;

    @Override public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        getLogger().info("====================================");
        getLogger().info(" KYOSHGUARD 0.1.0 | KYOSH.DEV");
        getLogger().info(" Join/command abuse monitor enabled");
        getLogger().info("====================================");
    }

    @Override public void onDisable() {
        joinTimes.clear(); commandTimes.clear(); savedLocations.clear();
        getLogger().info("KyoshGuard stopped safely.");
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        if (!getConfig().getBoolean("antibot.enabled", true)) return;
        Player player = event.getPlayer();
        long now = System.currentTimeMillis();
        Deque<Long> times = joinTimes.computeIfAbsent(player.getUniqueId(), k -> new ArrayDeque<>());
        trim(times, now, getConfig().getInt("antibot.join-window-seconds", 10) * 1000L);
        times.addLast(now);
        int limit = getConfig().getInt("antibot.max-joins-per-window", 7);
        if (times.size() > limit) {
            alert("JOIN RATE FLAG: " + player.getName() + " (" + times.size() + " joins inside configured window). Review manually; shared IPs/legitimate reconnects can cause false positives.");
        }
    }

    @EventHandler public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!getConfig().getBoolean("antiflood.enabled", true)) return;
        Player player = event.getPlayer();
        long now = System.currentTimeMillis();
        Deque<Long> times = commandTimes.computeIfAbsent(player.getUniqueId(), k -> new ArrayDeque<>());
        trim(times, now, getConfig().getInt("antiflood.command-window-seconds", 5) * 1000L);
        times.addLast(now);
        int limit = getConfig().getInt("antiflood.max-commands-per-window", 12);
        if (times.size() > limit) {
            alert("COMMAND RATE FLAG: " + player.getName() + " (" + times.size() + " commands in window). Review manually.");
            if (!getConfig().getBoolean("antiflood.alert-only", true)) {
                event.setCancelled(true);
                player.sendMessage(prefix() + ChatColor.YELLOW + "Command rate limited. Please slow down.");
            }
        }
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        joinTimes.remove(event.getPlayer().getUniqueId());
        commandTimes.remove(event.getPlayer().getUniqueId());
    }

    private void trim(Deque<Long> queue, long now, long windowMs) {
        while (!queue.isEmpty() && now - queue.peekFirst() > windowMs) queue.removeFirst();
    }

    private void alert(String message) {
        String line = "[KyoshGuard] " + message + " | " + Instant.now();
        getLogger().warning(line);
        recentAlerts.addFirst(line);
        while (recentAlerts.size() > 30) recentAlerts.removeLast();
        if (getConfig().getBoolean("alerts.notify-staff", true)) {
            for (Player p : Bukkit.getOnlinePlayers()) if (p.hasPermission("kyoshguard.alerts")) p.sendMessage(ChatColor.GOLD + line);
        }
        maybeOwnerTeleport();
    }

    private void maybeOwnerTeleport() {
        if (!getConfig().getBoolean("investigation.owner-teleport-on-alert", false)) return;
        String ownerText = getConfig().getString("investigation.owner-uuid", "");
        if (ownerText == null || ownerText.isBlank()) return;
        Player owner;
        try { owner = Bukkit.getPlayer(UUID.fromString(ownerText)); } catch (IllegalArgumentException ex) { return; }
        if (owner == null || !owner.isOnline() || !owner.hasPermission("kyoshguard.investigate")) return;
        long cooldown = getConfig().getLong("investigation.teleport-cooldown-seconds", 30) * 1000L;
        long now = System.currentTimeMillis();
        if (now - lastOwnerTp < cooldown) return;
        // Alerts are not player-specific proof; this feature only teleports to a random online player for observation.
        Player target = Bukkit.getOnlinePlayers().stream().filter(p -> !p.getUniqueId().equals(owner.getUniqueId())).findFirst().orElse(null);
        if (target == null) return;
        savedLocations.put(owner.getUniqueId(), owner.getLocation().clone());
        owner.teleport(target.getLocation());
        lastOwnerTp = now;
        owner.sendMessage(prefix() + ChatColor.YELLOW + " Auto-investigation teleport triggered. Use /kyoshguard back to return.");
    }

    private String prefix() { return ChatColor.DARK_GRAY + "[" + ChatColor.GOLD + "KyoshGuard" + ChatColor.DARK_GRAY + "] " + ChatColor.RESET; }


    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(prefix() + ChatColor.GOLD + "/kyoshguard help, status, alerts, check <player>, tp <player>, back, reload");
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("status")) {
            if (!sender.hasPermission("kyoshguard.view")) return deny(sender);
            sender.sendMessage(prefix() + "Join monitor: " + getConfig().getBoolean("antibot.enabled") + " | Command monitor: " + getConfig().getBoolean("antiflood.enabled") + " | Players: " + Bukkit.getOnlinePlayers().size());
            return true;
        }
        if (sub.equals("alerts")) {
            if (!sender.hasPermission("kyoshguard.view")) return deny(sender);
            if (recentAlerts.isEmpty()) sender.sendMessage(prefix() + "No recent alerts.");
            else recentAlerts.forEach(sender::sendMessage);
            return true;
        }
        if (sub.equals("check") && args.length >= 2) {
            if (!sender.hasPermission("kyoshguard.view")) return deny(sender);
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(prefix() + "Player not online."); return true; }
            sender.sendMessage(prefix() + "Player: " + target.getName() + " UUID: " + target.getUniqueId() + " World: " + target.getWorld().getName() + " XYZ: " + target.getLocation().getBlockX() + ", " + target.getLocation().getBlockY() + ", " + target.getLocation().getBlockZ());
            return true;
        }
        if (sub.equals("tp") && args.length >= 2) {
            if (!(sender instanceof Player staff) || !sender.hasPermission("kyoshguard.investigate")) return deny(sender);
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(prefix() + "Player not online."); return true; }
            savedLocations.put(staff.getUniqueId(), staff.getLocation().clone());
            staff.teleport(target.getLocation());
            sender.sendMessage(prefix() + "Teleported for investigation. /kyoshguard back returns you.");
            return true;
        }
        if (sub.equals("back")) {
            if (!(sender instanceof Player staff) || !sender.hasPermission("kyoshguard.investigate")) return deny(sender);
            Location loc = savedLocations.remove(staff.getUniqueId());
            if (loc == null) { sender.sendMessage(prefix() + "No saved return location."); return true; }
            staff.teleport(loc);
            sender.sendMessage(prefix() + "Returned to saved location.");
            return true;
        }
        if (sub.equals("reload")) {
            if (!sender.hasPermission("kyoshguard.admin")) return deny(sender);
            reloadConfig(); sender.sendMessage(prefix() + "Configuration reloaded."); return true;
        }
        sender.sendMessage(prefix() + ChatColor.RED + "Unknown subcommand. Use /kyoshguard help.");
        return true;
    }
    private boolean deny(CommandSender sender) { sender.sendMessage(prefix() + ChatColor.RED + "You don't have permission."); return true; }
}
