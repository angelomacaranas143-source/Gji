# pagani
Chat-claim loot events for Paper 26.3. Credits: haruDev

## Build the .jar
Target: Paper 26.3, Java 25. Build via GitHub Actions:

    mvn package

Your plugin is then at `target/pagani.jar`. Drop it in `/plugins`.

No setup? Push this folder to a GitHub repo - the Actions tab builds `pagani.jar` for you
(download it from the run's "Artifacts").

## Commands (alias: /lootall)
- `/pagani start <item> [amount] [seconds]` - e.g. `/pagani start golden_apple 32`
- `/pagani stop` | `/pagani status` | `/pagani reload` | `/pagani about`

Players type the claim word (default `W`) in chat to get the item, once per event.
Permissions: `pagani.admin` (op), `pagani.claim` (everyone).
