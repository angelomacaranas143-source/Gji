# Pagani — Paper 26.3

Chat-claim loot event plugin. Credits: haruDev.

## Build

This project targets Paper 26.3 and Java 25. The GitHub Actions workflow at `.github/workflows/build-pagani.yml` builds the plugin on every push to `main`, or when manually started from the Actions tab.

The compiled plugin is `target/pagani.jar`. Download the `Pagani-26.3` artifact from the successful Actions run, extract the downloaded artifact ZIP, and place `pagani.jar` in the server's `plugins` folder.

## Commands

- `/pagani start <item> [amount] [seconds]`
- `/pagani stop`
- `/pagani status`
- `/pagani reload`
- `/pagani about`

Alias: `/lootall`

Players type the configured claim word (default `W`) in chat once per event.

Permissions:
- `pagani.admin` — operator by default
- `pagani.claim` — everyone by default
