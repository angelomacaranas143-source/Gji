package dev.harudev.pagani;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Pagani - chat-claim loot events.
 * Credits: haruDev
 */
public final class Pagani extends JavaPlugin implements Listener, TabExecutor {

    private static final String CREDITS = "haruDev";

    private volatile boolean active;
    private Material eventItem;
    private int eventAmount;
    private long endsAt;
    private final Set<UUID> claimed = new HashSet<>();
    private BukkitTask endTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        PluginCommand cmd = getCommand("pagani");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        getLogger().info("Pagani enabled - made by " + CREDITS);
    }

    @Override
    public void onDisable() {
        active = false;
        if (endTask != null) {
            endTask.cancel();
            endTask = null;
        }
    }

    // ---------- helpers ----------

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private String raw(String key, String... kv) {
        String s = getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", kv[i + 1]);
        }
        return color(s);
    }

    private String prefixed(String key, String... kv) {
        return color(getConfig().getString("prefix", "&6[&ePAGANI&6] ")) + raw(key, kv);
    }

    private String pretty(Material m) {
        return m.name().toLowerCase(Locale.ROOT).replace('_', ' ');
    }

    private String claimWord() {
        return getConfig().getString("claim-word", "W");
    }

    private int parsePositive(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    // ---------- event logic ----------

    private void startEvent(Material item, int amount, int seconds) {
        claimed.clear();
        eventItem = item;
        eventAmount = amount;
        endsAt = System.currentTimeMillis() + seconds * 1000L;
        active = true;

        String amt = String.valueOf(amount);
        String name = pretty(item);
        String word = claimWord();

        Bukkit.broadcastMessage(prefixed("started"));
        Bukkit.broadcastMessage(prefixed("announce", "amount", amt, "item", name, "word", word));

        String title = raw("title");
        String subtitle = raw("subtitle", "amount", amt, "item", name, "word", word);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.sendTitle(title, subtitle, 5, 60, 10);
        }

        endTask = Bukkit.getScheduler().runTaskLater(this, () -> endEvent(false), seconds * 20L);
    }

    private void endEvent(boolean manual) {
        if (!active) {
            return;
        }
        active = false;
        if (endTask != null) {
            endTask.cancel();
            endTask = null;
        }
        Bukkit.broadcastMessage(prefixed(manual ? "stopped" : "ended", "count", String.valueOf(claimed.size())));
    }

    private void claim(Player p) {
        if (!active || !p.hasPermission("pagani.claim")) {
            return;
        }
        if (!claimed.add(p.getUniqueId())) {
            p.sendMessage(prefixed("already-claimed"));
            return;
        }
        Map<Integer, ItemStack> leftover = p.getInventory().addItem(new ItemStack(eventItem, eventAmount));
        for (ItemStack stack : leftover.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), stack);
        }
        p.sendMessage(prefixed("received", "amount", String.valueOf(eventAmount), "item", pretty(eventItem)));
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        if (!active) {
            return;
        }
        if (!e.getMessage().trim().equalsIgnoreCase(claimWord())) {
            return;
        }
        if (getConfig().getBoolean("hide-claim-message", true)) {
            e.setCancelled(true);
        }
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(this, () -> claim(p));
    }

    // ---------- commands ----------

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage(color("&6Pagani &7- &f/pagani <start|stop|reload|status|about>"));
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);

        if (sub.equals("about") || sub.equals("credits")) {
            s.sendMessage(color("&6&lPagani &7v" + getDescription().getVersion()));
            s.sendMessage(color("&7Credits: &e" + CREDITS));
            return true;
        }

        if (!s.hasPermission("pagani.admin")) {
            s.sendMessage(prefixed("no-permission"));
            return true;
        }

        switch (sub) {
            case "start": {
                if (a.length < 2) {
                    s.sendMessage(prefixed("usage-start"));
                    return true;
                }
                if (active) {
                    s.sendMessage(prefixed("already-running"));
                    return true;
                }
                Material m = Material.matchMaterial(a[1]);
                if (m == null || !m.isItem() || m.isAir()) {
                    s.sendMessage(prefixed("invalid-item"));
                    return true;
                }
                int max = getConfig().getInt("max-amount", 2304);
                int amount = 1;
                if (a.length >= 3) {
                    amount = parsePositive(a[2]);
                }
                if (amount < 1 || amount > max) {
                    s.sendMessage(prefixed("invalid-number", "max", String.valueOf(max)));
                    return true;
                }
                int seconds = getConfig().getInt("default-duration-seconds", 30);
                if (a.length >= 4) {
                    seconds = parsePositive(a[3]);
                }
                if (seconds < 1 || seconds > 3600) {
                    s.sendMessage(prefixed("invalid-number", "max", "3600"));
                    return true;
                }
                startEvent(m, amount, seconds);
                return true;
            }
            case "stop": {
                if (!active) {
                    s.sendMessage(prefixed("no-event"));
                    return true;
                }
                endEvent(true);
                return true;
            }
            case "reload": {
                reloadConfig();
                s.sendMessage(prefixed("reloaded"));
                return true;
            }
            case "status": {
                if (!active) {
                    s.sendMessage(prefixed("no-event"));
                    return true;
                }
                long left = Math.max(0, (endsAt - System.currentTimeMillis()) / 1000);
                s.sendMessage(prefixed("status",
                        "amount", String.valueOf(eventAmount),
                        "item", pretty(eventItem),
                        "count", String.valueOf(claimed.size()),
                        "left", String.valueOf(left)));
                return true;
            }
            default:
                s.sendMessage(color("&6Pagani &7- &f/pagani <start|stop|reload|status|about>"));
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        boolean admin = s.hasPermission("pagani.admin");
        if (a.length == 1) {
            for (String x : List.of("start", "stop", "reload", "status", "about")) {
                if (x.startsWith(a[0].toLowerCase(Locale.ROOT))) {
                    out.add(x);
                }
            }
        } else if (admin && a[0].equalsIgnoreCase("start")) {
            if (a.length == 2) {
                String pre = a[1].toLowerCase(Locale.ROOT);
                for (Material m : Material.values()) {
                    if (m.isLegacy() || !m.isItem()) {
                        continue;
                    }
                    String n = m.name().toLowerCase(Locale.ROOT);
                    if (n.startsWith(pre)) {
                        out.add(n);
                        if (out.size() >= 50) {
                            break;
                        }
                    }
                }
            } else if (a.length == 3) {
                out.addAll(List.of("1", "16", "32", "64"));
            } else if (a.length == 4) {
                out.addAll(List.of("15", "30", "60"));
            }
        }
        return out;
    }
}
